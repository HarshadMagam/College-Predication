
<?php

$host='Localhost';
$user='root';
$pass='';
$db='ca';

$con=mysqli_connect($host,$user,$pass,$db);
if($con)
	echo 'connection successful';
    echo "<br />";
#$sql="insert into mytable2(COLLEGE_ID,NAME,ADDRESS,DEPARTMENT,CUTTOFF) values ('3001',' KC College','Kopari Thane East Navi Mumbai','COMP IT EXTC ETRX','100')";
#$sql="UPDATE mytable2 SET NAME='saradr patel', ADDRESS='Andheri West', CUTTOFF='160' WHERE COLLEGE_ID='3001' ";
#$sql = "DELETE FROM mytable2 WHERE COLLEGE_ID='3001'";
$sql="insert into mytable2(university_rating,NAME)values  ('5','PRINCETON UNIVERSITY')";











$query=mysqli_query($con,$sql);
if($query)
	
	echo 'record Deleted successful';
else
	echo 'error';
?>