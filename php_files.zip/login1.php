<!DOCTYPE html>
<html>
<head>
	<title></title>
	
	 <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>GETTING STARTED WITH BRACKETS</title>
        <meta name="description" content="An interactive getting started guide for Brackets.">
	<link rel="stylesheet" type="text/css" href="bootstrap.css"> 
	<link rel="stylesheet" type="text/css" href="sa.css">
	
</head>
<body bg=#0000000><br><br>
	<div class="container">
		<div class="row">
			<div class="col-lg-6">
				<h2>Login Form</h2>
				<form action="validation.php" method="post">
					<div class ="form-group">
					<label><b>username</b></label>
					
					<input type="text" name="user" class="form-control">
					
					</div>
					<br><br>
				<div class ="form-group">
					<label><b>password</b></label>
					
					<input type="password" name="password" class="form-control">
					</div>
					<br><br>
					<button type= "submit" class="btn btn-ptr">login</button>
					
					
				</form>
			</div>
			<br>
			<hr>
			<br>	
			<div class="col-lg-6">
				<h2>Signin form</h2>
				<form action="registration.php" method="post">
					<div class ="form-group">
					<label><b>username</b></label>
					
					<input type="text" name="user" class="form-control">
					
					</div>
					<br><br>
					<div class ="form-group">
					
					<label><b>password</b></label>
				
					<input type="password" name="password" class="form-control">
					</div>
					<br><br>
					<button type= "submit" class="btn btn-ptr">Signin</button>
					
				</form>
			</div>
			
			</div>
</body>
</html>	