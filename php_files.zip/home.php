<?php

session_start();

?>
<!DOCTYPE html>
<html>
<head>
	
	
	<link rel="stylesheet" type="text/css" href="bootstrap.css"> 

	<link rel="stylesheet" type="text/css" href="sa.css"> 
	
	<title></title>
</head>
<body bgcolor="#EEFDEF">
<div class="container">
	<h1 align=center >welcome  <?php echo  $_SESSION['username'];  ?></h1>
	<br>
	<h2 align=center>DETAILS</h2>
	<br>
	
				<form action="p.php" method="post">
					<div align=center>
					<label><b>NAME</b></label>
					<br>
					<input type="text" name="NAME1" class="form-control">
					
					</div>
					<br><br>
				<div align=center>
					<label><b>CET</b></label>
					<br>
					<input type="text" name="CET1" class="form-control">
					</div>
					<br>
					<div align=center><br>
					<button type= "submit" class="btn btn-ptr">CHEK</button>
					</div><br>
					
				</form>
	
	
	
<br><br><br><br>
<div align=center>
	<a href="logout.php"> LOGOUT </a>
	</div>
</div>	
</body>
</html>