<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="sa.css"> 
</head>
<body>
<div class="container">

  <table class="table">


<?php

$host='Localhost';
$user='root';
$pass='';
$db='registration';

$con=mysqli_connect($host,$user,$pass,$db);
if($con)
	echo 'connection successfull';
    echo "<br />";
$sql="insert into mytable2(COLLEGE_ID,NAME,ADDRESS,DEPARTMENT,CUTTOFF) values ('3210','Excelsior Education Society's K.C. College of Engineering','Kopari Thane East Navi Mumbai','COMP IT EXTC ETRX','190')";


$name = $_POST['NAME1'];
$cet = $_POST['CET1'];

echo " <h1> <b><center><font face=Copperplate Gothic Bold ,size='6'><b>  $name You MAY GET FOLLOWING COLLEGES</b></font></center></h1>";
#echo"      <h1 align=center >    $name you may get  following colleges</h1>";

$q = " select * from mytable2 where $cet > CUTTOFF";


$result = mysqli_query($con,$q);

 echo "<br />";
 echo "<br />";



echo "<table  border='1' align=center >
<tr>
<th>COLLEGE_ID</th>
<th>NAME</th>
<th>ADDRESS</th>
<th>DEPARTMENT</th>
<th>CUTTOFF</th>
</tr>";


while($row = mysqli_fetch_array($result))
{
	
echo "<tr>";	
echo "<h2><td>" .$row['COLLEGE_ID'] . "</td></h2>";
echo "<h2><td>" .$row['NAME'] . "</td></h2>";
echo "<h2><td>" .$row['ADDRESS'] . "</td></h2>";
echo "<h2><td>" .$row['DEPARTMENT']. "</td></h2>";
echo "</h2><td>" .$row['CUTTOFF'] . "</td></h2>";

}
echo "</table>";















$query=mysqli_query($con,$sql);
if($query)
	echo 'data inserted successfull';
?>
  </table>
</div>
</body>
</html>